"""
URL configuration for eduBudddy project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

from eduBudddy import views, user_login

# from .import views, user_login

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.HOME,name='home'),


    path('accounts/register',user_login.REGISTER,name='register'),
    path('accounts/', include('django.contrib.auth.urls')),
    path('do_Login',user_login.DO_LOGIN, name='doLogin'),
    path('accounts/login/',user_login.DO_LOGIN, name='login'),
    path('accounts/profile',user_login.PROFILE,name='profile'),
    path('account/profile/update',user_login.PROFILE_UPDATE, name='profile_update'),
    path('accounts/logout_user', user_login.LOGOUT, name='logout'),

    path('dashboard',views.DASHBOARD,name='dashboard'),
    path('qa',views.QA,name='qa'),
    path('sm',views.SM,name='sm'),
    path('quiz',views.QUIZ,name='quiz'),
    path('quiz_chart',views.QUIZ_CHART,name='quiz_chart')

]
